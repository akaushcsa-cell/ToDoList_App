package com.example.todoapp.adapter

import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.todoapp.R
import com.example.todoapp.data.Todo
import com.example.todoapp.databinding.ItemTodoBinding
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class TodoAdapter(
    private val onDeleteClick: (Todo) -> Unit
) : ListAdapter<Todo, TodoAdapter.TodoViewHolder>(TodoDiffCallback()) {

    private var currentColor: Int = -1

    fun updateColor(color: Int) {
        currentColor = color
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TodoViewHolder {
        val binding = ItemTodoBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return TodoViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TodoViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class TodoViewHolder(private val binding: ItemTodoBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(todo: Todo) {
            binding.apply {
                textViewTitle.text = todo.title
                
                val sdf = SimpleDateFormat("HH:mm:ss, dd/MM", Locale.getDefault())
                textViewTimestamp.text = sdf.format(Date(todo.timestamp))

                // Handle image
                todo.imagePath?.let { path ->
                    val imageFile = File(path)
                    if (imageFile.exists()) {
                        imageViewTodo.visibility = View.VISIBLE
                        imageViewTodo.setImageURI(android.net.Uri.fromFile(imageFile))
                    } else {
                        imageViewTodo.visibility = View.GONE
                    }
                } ?: run {
                    imageViewTodo.visibility = View.GONE
                }

                // Set card background color
                if (currentColor != -1) {
                    root.setCardBackgroundColor(currentColor)
                } else {
                    root.setCardBackgroundColor(ContextCompat.getColor(root.context, R.color.todo_purple))
                }

                // Set delete button color
                buttonDelete.imageTintList = ColorStateList.valueOf(
                    ContextCompat.getColor(root.context, android.R.color.white)
                )

                buttonDelete.setOnClickListener {
                    onDeleteClick(todo)
                }
            }
        }
    }

    class TodoDiffCallback : DiffUtil.ItemCallback<Todo>() {
        override fun areItemsTheSame(oldItem: Todo, newItem: Todo): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Todo, newItem: Todo): Boolean {
            return oldItem == newItem
        }
    }
}
