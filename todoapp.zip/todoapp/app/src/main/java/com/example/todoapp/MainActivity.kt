package com.example.todoapp

import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Bundle
import android.view.inputmethod.EditorInfo
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.todoapp.adapter.TodoAdapter
import com.example.todoapp.data.Todo
import com.example.todoapp.databinding.ActivityMainBinding
import com.example.todoapp.viewmodel.TodoViewModel

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: TodoViewModel
    private lateinit var todoAdapter: TodoAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this)[TodoViewModel::class.java]

        setupRecyclerView()
        setupInput()
        setupThemeProgress()
        observeTodos()
        
        // Set initial border color
        updateEditTextBorder(ContextCompat.getColor(this, R.color.todo_purple))
    }

    private fun setupRecyclerView() {
        todoAdapter = TodoAdapter(
            onDeleteClick = { todo ->
                viewModel.delete(todo)
            }
        )

        binding.recyclerView.apply {
            adapter = todoAdapter
            layoutManager = LinearLayoutManager(this@MainActivity)
        }
    }

    private fun setupInput() {
        binding.addButton.setOnClickListener {
            addTodo()
        }

        binding.todoInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                addTodo()
                true
            } else {
                false
            }
        }
    }

    private fun setupThemeProgress() {
        binding.themeSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                binding.progressText.text = "$progress%"
                updateThemeColor(progress)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun updateEditTextBorder(color: Int) {
        val shape = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(ContextCompat.getColor(this@MainActivity, android.R.color.white))
            cornerRadius = resources.getDimension(R.dimen.corner_radius)
            setStroke(4, color)
        }
        binding.todoInput.background = shape
    }

    private fun updateThemeColor(progress: Int) {
        val colorRes = when {
            progress <= 10 -> R.color.progress_10
            progress <= 20 -> R.color.progress_20
            progress <= 30 -> R.color.progress_30
            progress <= 40 -> R.color.progress_40
            progress <= 50 -> R.color.progress_50
            progress <= 60 -> R.color.progress_60
            progress <= 70 -> R.color.progress_70
            progress <= 80 -> R.color.progress_80
            progress <= 90 -> R.color.progress_90
            else -> R.color.progress_100
        }

        val color = ContextCompat.getColor(this, colorRes)
        
        // Update Add button color
        binding.addButton.backgroundTintList = ColorStateList.valueOf(color)
        
        // Update progress bar color
        try {
            val progressDrawable = binding.themeSeekBar.progressDrawable as LayerDrawable
            val progress = progressDrawable.findDrawableByLayerId(android.R.id.progress)
            progress.setTint(color)
            
            // Update thumb color
            binding.themeSeekBar.thumb?.setTint(color)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        
        // Update EditText border
        updateEditTextBorder(color)
        
        // Update TodoAdapter color
        todoAdapter.updateColor(color)
        todoAdapter.notifyDataSetChanged()
    }

    private fun addTodo() {
        val todoText = binding.todoInput.text.toString().trim()
        if (todoText.isNotEmpty()) {
            val todo = Todo(title = todoText)
            viewModel.insert(todo)
            binding.todoInput.text.clear()
        }
    }

    private fun observeTodos() {
        viewModel.allTodos.observe(this) { todos ->
            todoAdapter.submitList(todos)
        }
    }
}